from ._curriculum_clustering import CurriculumClustering
from ._version import __version__

__all__ = ['CurriculumClustering', '__version__']
